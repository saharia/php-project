<?php
	session_start();

	require '../../db/mysql/database.php';

	require '../../model/'.$_SESSION['path'].'/user.php';

	require '../../model/'.$_SESSION['path'].'/client.php';

   	require '../../model/'.$_SESSION['path'].'/clientuserallocation.php';

	require '../../model/'.$_SESSION['path'].'/configuration.php';

	require '../../model/'.$_SESSION['path'].'/markedmsg.php';

	require '../../model/'.$_SESSION['path'].'/privatemsg.php';

	require '../../model/'.$_SESSION['path'].'/screen.php';

	require '../../model/'.$_SESSION['path'].'/setting.php';

	require '../../model/'.$_SESSION['path'].'/usernew.php';

	require '../../model/'.$_SESSION['path'].'/usergroup.php';

	require '../../model/'.$_SESSION['path'].'/usergroupper.php';

	require '../../model/'.$_SESSION['path'].'/querymanagement.php';

	require '../../model/'.$_SESSION['path'].'/clientlogin.php';

	require '../../model/'.$_SESSION['path'].'/clientloginmain.php';
	
	require '../../model/'.$_SESSION['path'].'/filemanagement.php';

	require '../../model/'.$_SESSION['path'].'/admin.php';
	
	require '../../model/'.$_SESSION['path'].'/inbox.php';

	require '../../model/'.$_SESSION['path'].'/msgdisplay.php';
	
	require '../../model/'.$_SESSION['path'].'/dashadminprivatemsg.php';
	
	require '../../model/'.$_SESSION['path'].'/menu.php';
	
	require '../../model/'.$_SESSION['path'].'/module.php';
	
	require '../../model/'.$_SESSION['path'].'/client_menu.php';
	
	require '../../model/'.$_SESSION['path'].'/client_module.php';

	require '../../model/'.$_SESSION['path'].'/chat.php';

	require '../../model/'.$_SESSION['path'].'/chatdetail.php';
	
	require '../../model/'.$_SESSION['path'].'/task.php';

	require '../../model/'.$_SESSION['path'].'/adminsetting.php';

	require '../../model/'.$_SESSION['path'].'/tasknotes.php';
	
	$tasks = new Task($db);
	
	$menus = new Menu($db);
	
	$modules = new Module($db);
	
	$client_menus = new ClientMenu($db);
	
	$client_modules = new ClientModule($db);

	$users = new Users($db);

	$clients = new Client($db);

	$clientuserallocations = new Clientuserallocation($db);

	$configurations = new Configuration($db);

	$markedmsgs = new Markedmsg($db);

	$privatemsgs = new Privatemsg($db);

	$screens = new Screen($db);

	$settings = new Setting($db);

	$usernews = new Usernew($db);

	$usergroups = new Usergroup($db);

	$usergrouppers = new Usergroupper($db);

	$querymanagements = new Querymanagement($db);
	
	$clientlogins = new Clientlogin($db);

	$clientloginmains= new Clientloginmain($db);

	$filemanagements= new Filemanagement($db);

	$admins= new Admin($db);

	$inboxs= new Inbox($db);
	
	$msgdisplays =new  Msgdisplay($db);	
	
	$dashadminprivatemsgs =new Dashadminprivatemsg($db);

	$chats =new Chat($db);

	$chatdetails =new  Chatdetail($db);

	$adminsettings =new  Adminsetting($db);

	$tasknotes =new  Tasknote($db);
	
	$errors = array();
?>
