<?php

session_start();

$_SESSION['directory']=dirname(__FILE__);

require 'db/mysql/database.php';

require 'Login.php';

require 'model/user/menu.php';

require 'model/user/usernew.php';

require 'model/user/client.php';

$menus=new Menu($db);

$usernews=new Usernew($db);

$clients=new Client($db);

$loginObj= new MainLogin($db);

$msg="";
$tsk="";
$up="";
$clientup="";
	$menu=$menus->getOtherMenus('inbox','N');
	foreach($menu as $rs)
	{
		$msg=$rs['menu_id'];
	}
	$menu=$menus->getOtherMenus('profile','N');
	foreach($menu as $rs)
	{
		$up=$rs['menu_id'];
	}
	$menu=$menus->getOtherMenus('profile','Y');
	foreach($menu as $rs)
	{
		$clientup=$rs['menu_id'];
	}
	
 if (empty($_POST) === false) 
  {
$bool=true;
	$username = trim($_POST['txtuname']);
	$password = trim($_POST['txtpword']);

	if (empty($username) === true || empty($password) === true) 
	{
		header('Location: index.php?msg=Sorry, but we need your username and password.');
	} 
	else 
	{
		$login = $loginObj->checklogin($username, $password);
		if ($login === false) 
		{
			header('Location: index.php?msg=Sorry, that username and password is not Valid.');
		}
		else 
		{
			$loginObj->insertLoggedDetail($_SESSION['uid']);
$hidredirect='';
			$quick=$usernews->get_quickuser($_SESSION['uid']);
			$qclient=$clients->get_quickclient($_SESSION['uid']);

			if ($_SESSION['ugid'] == -5)
			{
				if(count($qclient)>0)
				{
					header('Location: views/'.$_SESSION['path'].'/index.php?id='.$clientup);
				}
				else if($_POST['hidpage'] != '-10')
				{
					header('Location: views/'.$_SESSION['path'].'/index.php?id='.$_POST['hidpage']);
				}
				else
				{
					header('Location: views/'.$_SESSION['path'].'/index.php?id='.$msg);
				}

			}
			else
			{
				if(count($quick)>0)
				{
					header('Location: views/'.$_SESSION['path'].'/index.php?id='.$up);
				}
				else if($_POST['hidpage'] != '-10')
				{
					header('Location: views/'.$_SESSION['path'].'/index.php?id='.$_POST['hidpage']);
				}
				else
				{
					header('Location: views/'.$_SESSION['path'].'/index.php?id=1');
				}
			}
			exit();
		}
	}
} 

?>

