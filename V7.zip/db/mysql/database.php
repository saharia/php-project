<?php
/*  $config = array(
 'host' => 'caappautomate.db.12915445.hostedresource.com',
 'username' => 'caappautomate',
 'password' => 'Ca123#123',
 'dbname' => 'caappautomate'
 );

 $db = new PDO('mysql:host=' . $config['host'] . ';dbname=' . $config['dbname'], $config['username'], $config['password']);

 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);*/

$config = array(
 'host' => 'localhost',
 'username' => 'root',
 'password' => '',
 'dbname' => 'ca'
 );

 $db = new PDO('mysql:host=' . $config['host'] . ';dbname=' . $config['dbname'], $config['username'], $config['password']);

 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>
