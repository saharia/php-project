// make console.log safe to use
window.console||(console={log:function(){}});

$(document).ready(function() {

    conditionizr({
        ie8: { 
            customScript: "js/excanvas.min.js" 
        }         
    });

    //Init the genyxAdmin plugin
    $.genyxAdmin({
        fixedWidth: false,// make true if you want to use fixed widht instead of fluid version.
        customScroll: false,// Custom scroll for page. true or false 
        responsiveTablesCustomScroll: true,// custom scroll for responsive tables. true or false
        backToTop: true,//show back to top , true or false
        navigation: {
            useNavMore: true, //use arrow for hint. ture or false
            navMoreIconDown: 'i-arrow-down-2', //icon for down state.
            navMoreIconUp: 'i-arrow-up-2',//icon for up state
            rotateIcon: true//rotate icon on hover , true or false
        },
        setCurrent: {
            absoluteUrl: false, //put true if use absolute path links. example http://www.host.com/dashboard instead of /dashboard
            subDir: '' //if you put template in sub dir you need to fill here. example '/html'
        },
        collapseNavIcon: 'i-arrow-left-7', //icon for collapse navigation button
        collapseNavRestoreIcon: 'i-arrow-right-8', //icon for restore navigation button
        rememberNavState: true, //remember if menu is collapsed 
        remeberExpandedSub: false, //remeber expanded sub menu by user
        hoverDropDown: false, //set false if not want to show dropdown on hover ( click instead)
        accordionIconShow: 'i-arrow-down-2',//icon for accordion expand
        accordionIconHide: 'i-arrow-up-2',//icon for accordion hide
        showThemer: false
    });

    //Disable certain links
    $('a[href^=#]').click(function (e) {
        e.preventDefault()
    })

    //------------- Prettify code  -------------//
    window.prettyPrint && prettyPrint();

    //------------- Bootstrap tooltips -------------//
    $("[data-toggle=tooltip]").tooltip ({});
    $(".tip").tooltip ({placement: 'top', container: 'body'});
    $(".tipR").tooltip ({placement: 'right', container: 'body'});
    $(".tipB").tooltip ({placement: 'bottom', container: 'body'});
    $(".tipL").tooltip ({placement: 'left', container: 'body'});
    //--------------- Popovers ------------------//
    //using data-placement trigger
    $("a[data-toggle=popover]")
      .popover()
      .click(function(e) {
        e.preventDefault()
    });

    $('#fixedwidth').click(function() {
        $.genyxAdmin({fixedWidth: true});
    });

    //init this last don`t change
    //------------- Uniform  -------------//
    //add class .nostyle if not want uniform to style field
    //$("input, textarea, select").not('.nostyle').uniform();
    $("[type='checkbox'], [type='radio'], [type='file'], select").not('.toggle, .select2, .multiselect').uniform();
});

function ajaxfunction(requestPage, responseAssign){
	var ajaxRequest;  // The variable that makes Ajax possible!
	try{
		// Opera 8.0+, Firefox, Safari
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		// Internet Explorer Browsers
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				// Something went wrong
				alert("Your browser broke!");
				return false;
			}
		}
	}
	
	// Create a function that will receive data sent from the server
	ajaxRequest.onreadystatechange = function(){
		if(ajaxRequest.readyState == 4){
			eval(responseAssign);
		}
	}
	
	ajaxRequest.open("GET", requestPage, true);
	ajaxRequest.send(null); 
}

function allocation(cid,uid,path)
{
var op="";
	ajaxfunction("../../model/"+path+"/clientAllocation.php?cid="+cid+"&uid="+uid, "$('#allocationCount"+uid+"').html(ajaxRequest.responseText);");
}


function chat(uid,path,redirect)
{
var op="";
	ajaxfunction("../../model/"+path+"/chatBegin.php?rid="+uid+"&hidredirect="+redirect, "$('#chatlayout').html(ajaxRequest.responseText);");
}
function insertChat()
{
	ajaxfunction("../../model/"+$('#hidpath').val()+"/insertChat.php?cid="+$('#hidchat').val()+"&hidredirect="+$('#hidredirect').val()+"&message="+$('#messagetxt').val(), "$('#chatMessage').html(ajaxRequest.responseText);$('#messagetxt').val('');");
	
}

function showFile(id,mode)
{
	$('#saveBut').attr('disabled',false);
	ajaxfunction("../../model/"+$('#hidpath').val()+"/showFile.php?hidredirect="+$('#hidredirect').val()+"&id="+id+"&mode="+mode, "$('#filedisplay').html(ajaxRequest.responseText);initUploader("+id+");");
	$('.hlight').css('background-color','white');
	$('#hlight'+id).css('background-color','rgb(240,240,240)');
	$('#allBut').removeClass('btn-default');
	$('#sentBut').removeClass('btn-default');
	$('#receiveBut').removeClass('btn-default');
	$('#allBut').addClass('btn-success');
	$('#sentBut').addClass('btn-success');
	$('#receiveBut').addClass('btn-success');
}
function deleteFile(mode, id, hidredirect,path)
{
	ajaxfunction("../../model/"+$('#hidpath').val()+"/deleteFile.php?hidredirect="+hidredirect+"&id="+id+"&mode="+mode+"&path="+path, "$('#filedisplay').html(ajaxRequest.responseText);");
}

function insertUploadedFile(fname,uid)
{
	var op="";
	ajaxfunction("../../model/"+$('#hidpath').val()+"/insertUploadedFile.php?fname="+fname+"&uid="+uid, "op=ajaxRequest.responseText;");
}
