//adminadmintolevel1.php
$(".clientdiv").draggable({
revert: "invalid"
});
$(".employeediv").droppable({
drop:function(e,ui)
{
alert(ui.draggable.attr("data-source"));
	ui.draggable.detach();
	ui.draggable.css("left","0px");
	ui.draggable.css("top","0px");
	allocation(ui.draggable.attr("data-source"),$(this).attr("data-source"),$('#hidmode').val());
	//alert("Client Id " + ui.draggable.attr("data-source") + " moves to " + $(this).attr("data-source"));
	ui.draggable.appendTo($(this));
}
});

//assignclient.php


//dashboard.php
